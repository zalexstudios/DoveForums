<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

{breadcrumbs}

<div class="btn-toolbar pagination-toolbar" role="toolbar">

    <div class="btn-group">

        {btn_add_group}

    </div>

</div>

<div class="panel panel-default">

    <div class="panel-heading">

        <h3 class="panel-title"><?=lang('tle_groups');?></h3>

    </div>

    <div class="panel-body">

        {tbl_groups}

    </div>

</div>