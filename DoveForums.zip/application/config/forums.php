<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config['tables'] = array(
    'categories' => 'categories',
    'discussions' => 'discussions',
    'comments' => 'comments',
    'users' => 'users',
    'languages' => 'language_packs'
);
