<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config['include_home'] = 'Forums';
$config['divider'] = '&nbsp;';
$config['container_open'] = '<ol class="breadcrumb">';
$config['container_close'] = '</ol>';
$config['crumb_open'] = '<li>';
$config['crumb_close'] = '</li>';
$config['auto_uppercase'] = TRUE;