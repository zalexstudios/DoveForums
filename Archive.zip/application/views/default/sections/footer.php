<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

<footer>

    <p class="text-center text-muted"><small>{copy_text}</small></p>

</footer>