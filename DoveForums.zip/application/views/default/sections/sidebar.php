<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

<ul class="list-group">

    <li class="list-group-item list-group-item-info"><?= lang('tle_categories');?></li>

    {categories}

    <li class="list-group-item">{name} <span class="badge">{discussion_count}</span></li>

    {/categories}

</ul>
