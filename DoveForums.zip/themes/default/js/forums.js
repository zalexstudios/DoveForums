$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip({
        container: 'body'
    });
});