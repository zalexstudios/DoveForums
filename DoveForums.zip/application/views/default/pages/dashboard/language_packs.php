<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

{breadcrumbs}

<div class="btn-toolbar pagination-toolbar" role="toolbar">

    <div class="btn-group">

        {btn_add_language}

    </div>

</div>

<div class="panel panel-default">

    <div class="panel-heading">

        <h3 class="panel-title"><?=lang('tle_language_packs');?></h3>

    </div>

    <div class="panel-body">

        {tbl_language_packs}

    </div>

</div>